package com.example.pixelplay

import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.border
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import androidx.media3.common.C

private val Ink = Color(0xFF101116)
private val Panel = Color(0xFF1C1D25)
private val Lavender = Color(0xFFD0BCFF)
private val Muted = Color(0xFFAAA9B5)

private data class PlayerTheme(
    val name: String,
    val background: Color,
    val panel: Color,
    val accent: Color
)

private val playerThemes = listOf(
    PlayerTheme("Pixel Purple", Color(0xFF101116), Color(0xFF1C1D25), Color(0xFFD0BCFF)),
    PlayerTheme("AMOLED Black", Color(0xFF000000), Color(0xFF101010), Color(0xFF8AB4F8)),
    PlayerTheme("Ocean Blue", Color(0xFF071522), Color(0xFF10283A), Color(0xFF62D5FF)),
    PlayerTheme("Forest Green", Color(0xFF0B1712), Color(0xFF17271E), Color(0xFF8BE9A4)),
    PlayerTheme("Sunset Orange", Color(0xFF1A100D), Color(0xFF2B1B16), Color(0xFFFFB680)),
    PlayerTheme("Rose Pink", Color(0xFF1A0E17), Color(0xFF2B1726), Color(0xFFFF9ACB)),
    PlayerTheme("Light", Color(0xFFF5F5FA), Color(0xFFFFFFFF), Color(0xFF6750A4))
)

class MainActivity : ComponentActivity() {
    @androidx.media3.common.util.UnstableApi
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 17, 22)
        window.navigationBarColor = android.graphics.Color.rgb(16, 17, 22)
        window.decorView.systemUiVisibility = 0
        setContent { PixelPlayApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
private fun PixelPlayApp() {
    val context = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = false
        }
    }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("No video selected") }
    var subtitleUri by remember { mutableStateOf<Uri?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var speed by remember { mutableFloatStateOf(1f) }
    var showSpeedMenu by remember { mutableStateOf(false) }
    var showMore by remember { mutableStateOf(false) }
    var selectedTheme by remember { mutableStateOf(playerThemes.first()) }
    var showThemeMenu by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Choose a video to get started") }

    val audioPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            videoUri = uri
            videoName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')
                ?.takeIf { it.isNotBlank() } ?: "Selected audio"
            subtitleUri = null
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            player.playWhenReady = true
            status = "Playing audio"
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            videoUri = uri
            videoName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')
                ?.takeIf { it.isNotBlank() } ?: "Selected video"
            subtitleUri = null
            val item = MediaItem.Builder().setUri(uri).build()
            player.setMediaItem(item)
            player.prepare()
            player.playWhenReady = true
            status = "Playing your video"
        }
    }
    val subtitlePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null && videoUri != null) {
            subtitleUri = uri
            val subtitle = MediaItem.SubtitleConfiguration.Builder(uri)
                .setMimeType(
                    when (uri.lastPathSegment?.substringAfterLast('.', "")?.lowercase()) {
                        "vtt" -> MimeTypes.TEXT_VTT
                        "ssa", "ass" -> MimeTypes.TEXT_SSA
                        else -> MimeTypes.APPLICATION_SUBRIP
                    }
                )
                .setLanguage("und")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            player.setMediaItem(
                MediaItem.Builder().setUri(videoUri!!).setSubtitleConfigurations(listOf(subtitle)).build()
            )
            player.prepare()
            player.playWhenReady = true
            status = "Subtitle loaded"
        } else if (videoUri == null) {
            status = "Choose a video before adding subtitles"
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) duration = player.duration.coerceAtLeast(0L)
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                status = "Can't play this file: ${error.errorCodeName}"
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(player) {
        while (true) {
            position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.takeIf { it > 0 } ?: 0L
            delay(400)
        }
    }

    val theme = selectedTheme
    val isLightTheme = theme.name == "Light"
    val foreground = if (isLightTheme) Color(0xFF17151D) else Color.White
    val mutedForeground = if (isLightTheme) Color(0xFF5D5967) else Muted

    MaterialTheme(
        colorScheme = if (isLightTheme) lightColorScheme(
            primary = theme.accent,
            onPrimary = Color.White,
            background = theme.background,
            surface = theme.panel,
            onSurface = foreground,
            secondary = theme.accent
        ) else darkColorScheme(
            primary = theme.accent,
            onPrimary = Color(0xFF101116),
            background = theme.background,
            surface = theme.panel,
            onSurface = foreground,
            secondary = theme.accent
        )
    ) {
        Scaffold(containerColor = theme.background) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.foundation.Image(
                        painter = painterResource(id = com.example.pixelplay.R.drawable.pixelplay_logo),
                        contentDescription = "PixelPlay logo",
                        modifier = Modifier.size(50.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("PixelPlay", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = foreground)
                        Text("GLASS • VIDEO • AUDIO", fontSize = 10.sp, color = mutedForeground, letterSpacing = 1.5.sp)
                    }
                    Text("MEDIA", color = theme.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(theme.panel.copy(alpha = 0.76f), RoundedCornerShape(24.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(24.dp))
                        .padding(12.dp)
                ) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                player = null
                                useController = true
                                controllerAutoShow = true
                                controllerShowTimeoutMs = 3000
                                setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                                layoutParams = FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            }
                        },
                        update = { it.player = player },
                        modifier = Modifier.fillMaxWidth().height(230.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(videoName, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = foreground, maxLines = 2)
                    Text(status, fontSize = 12.sp, color = mutedForeground)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(formatTime(position), fontSize = 11.sp, color = mutedForeground)
                        Slider(
                            value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                            onValueChange = { if (duration > 0) player.seekTo(it.toLong()) },
                            valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()),
                            modifier = Modifier.weight(1f).height(34.dp),
                            colors = SliderDefaults.colors(
                                thumbColor = theme.accent,
                                activeTrackColor = theme.accent,
                                inactiveTrackColor = Color.DarkGray
                            )
                        )
                        Text(formatTime(duration), fontSize = 11.sp, color = mutedForeground)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledTonalButton(onClick = { player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0)) }) {
                            Text("−10s")
                        }
                        Button(
                            onClick = {
                                if (player.isPlaying) player.pause()
                                else if (videoUri != null) player.play()
                                else videoPicker.launch(arrayOf("video/*"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = theme.accent, contentColor = Color(0xFF101116))
                        ) { Text(if (isPlaying) "Ⅱ Pause" else "▶ Play") }
                        FilledTonalButton(onClick = {
                            val end = player.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
                            player.seekTo((player.currentPosition + 10_000).coerceAtMost(end))
                        }) { Text("+10s") }
                    }
                }

                Text("YOUR LIBRARY", fontSize = 12.sp, color = mutedForeground, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Button(
                    onClick = { videoPicker.launch(arrayOf("video/*")) },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = theme.accent, contentColor = Color(0xFF101116))
                ) { Text("＋  Choose video from device", fontWeight = FontWeight.Bold) }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { audioPicker.launch(arrayOf("audio/*")) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("♫ Choose audio") }
                    Box(Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { showSpeedMenu = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp)
                        ) { Text("Speed  ${speed}×") }
                        DropdownMenu(expanded = showSpeedMenu, onDismissRequest = { showSpeedMenu = false }) {
                            listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { rate ->
                                DropdownMenuItem(
                                    text = { Text("${rate}×") },
                                    onClick = {
                                        speed = rate
                                        player.setPlaybackSpeed(rate)
                                        showSpeedMenu = false
                                    }
                                )
                            }
                        }
                    }
                    OutlinedButton(
                        onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/vtt", "text/plain", "*/*")) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("Subtitles") }
                }

                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(theme.panel.copy(alpha = 0.70f), RoundedCornerShape(20.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("APP THEMES", fontSize = 12.sp, color = mutedForeground, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(theme.name, color = foreground, fontWeight = FontWeight.SemiBold)
                            Text("iOS-inspired glass style", color = mutedForeground, fontSize = 12.sp)
                        }
                        Box {
                            OutlinedButton(onClick = { showThemeMenu = true }) { Text("Change theme") }
                            DropdownMenu(expanded = showThemeMenu, onDismissRequest = { showThemeMenu = false }) {
                                playerThemes.forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option.name) },
                                        leadingIcon = {
                                            Box(Modifier.size(18.dp).background(option.accent, RoundedCornerShape(50)))
                                        },
                                        onClick = {
                                            selectedTheme = option
                                            showThemeMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        playerThemes.forEach { option ->
                            androidx.compose.foundation.layout.Box(
                                modifier = Modifier.weight(1f).height(28.dp)
                                    .background(option.accent, RoundedCornerShape(10.dp))
                            )
                        }
                    }
                }

                OutlinedButton(
                    onClick = { showMore = !showMore },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) { Text(if (showMore) "Hide player options  ↑" else "More player options  ↓") }

                if (showMore) {
                    Card(colors = CardDefaults.cardColors(containerColor = theme.panel.copy(alpha = 0.78f))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Playback", fontWeight = FontWeight.Bold, color = Lavender)
                            Text("Audio and subtitle track selection can vary by file format. Use the controls inside the video player for the tracks exposed by the media.")
                            Text("Supported formats depend on Android device codecs. MP4, WebM and many common H.264/AAC files are usually good starting points.")
                            Text("External subtitle: choose an .srt or .vtt file after selecting a video.")
                        }
                    }
                }

                Text(
                    "PixelPlay • Built with Android Media3",
                    modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    color = mutedForeground,
                    fontSize = 11.sp
                )
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms.coerceAtLeast(0L) / 1000)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) "%d:%02d:%02d".format(hours, minutes, seconds)
    else "%02d:%02d".format(minutes, seconds)
}
