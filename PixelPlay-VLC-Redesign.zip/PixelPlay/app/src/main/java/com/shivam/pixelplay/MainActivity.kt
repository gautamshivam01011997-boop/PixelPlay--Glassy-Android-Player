package com.shivam.pixelplay

import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

private val AppBackground = Color(0xFF101010)
private val Panel = Color(0xFF202020)
private val VLCOrange = Color(0xFFFF8800)
private val MainText = Color(0xFFF5F5F5)
private val SecondaryText = Color(0xFFBDBDBD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 16, 16)
        window.navigationBarColor = android.graphics.Color.rgb(16, 16, 16)
        setContent { PixelPlayApp() }
    }
}

private data class VideoEntry(val uri: Uri, val name: String)

@Composable
private fun PixelPlayApp() {
    val context = LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("No video selected") }
    var playbackError by remember { mutableStateOf<String?>(null) }
    val recentVideos = remember { mutableStateListOf<VideoEntry>() }

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Some providers do not offer persistable permissions.
            }
            val name = queryDisplayName(context, uri)
            selectedUri = uri
            selectedName = name
            playbackError = null
            recentVideos.removeAll { it.uri == uri }
            recentVideos.add(0, VideoEntry(uri, name))
        }
    }

    LaunchedEffect(selectedUri) {
        val uri = selectedUri ?: return@LaunchedEffect
        try {
            playbackError = null
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            player.playWhenReady = true
        } catch (e: Exception) {
            playbackError = e.message ?: "Unable to open this video."
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                playbackError = "This video format may not be supported (${error.errorCodeName}). Try another video."
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = VLCOrange,
        background = AppBackground,
        surface = Panel,
        onPrimary = Color.Black,
        onBackground = MainText,
        onSurface = MainText
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = AppBackground) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.size(48.dp)
                            .background(VLCOrange, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PlayArrow,
                            contentDescription = "PixelPlay",
                            tint = Color.Black,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("PixelPlay", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = MainText)
                        Text("VIDEO PLAYER", fontSize = 11.sp, color = SecondaryText, letterSpacing = 2.sp)
                    }
                    Text("VLC STYLE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VLCOrange)
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Black)
                ) {
                    if (selectedUri != null) {
                        AndroidView(
                            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    player = player
                                    useController = true
                                    controllerAutoShow = true
                                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    layoutParams = ViewGroup.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                }
                            },
                            update = { it.player = player }
                        )
                    } else {
                        Box(
                            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                                .background(Color(0xFF080808)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Filled.Movie,
                                    contentDescription = null,
                                    tint = VLCOrange,
                                    modifier = Modifier.size(54.dp)
                                )
                                Spacer(Modifier.height(8.dp))
                                Text("Choose a video to start", color = SecondaryText, fontSize = 14.sp)
                            }
                        }
                    }
                }

                Button(
                    onClick = { videoPicker.launch(arrayOf("video/*")) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VLCOrange,
                        contentColor = Color.Black
                    )
                ) {
                    Icon(Icons.Filled.FolderOpen, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Open video", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                if (selectedUri != null) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("NOW PLAYING", color = VLCOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        Text(
                            selectedName,
                            color = MainText,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                playbackError?.let { error ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF3A1D1D)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(error, modifier = Modifier.padding(12.dp), color = Color(0xFFFFC9C9), fontSize = 13.sp)
                    }
                }

                Divider(color = Color(0xFF383838))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.VideoLibrary, contentDescription = null, tint = VLCOrange)
                    Spacer(Modifier.width(8.dp))
                    Text("Recent videos", color = MainText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }

                if (recentVideos.isEmpty()) {
                    Text(
                        "Your selected videos will appear here.",
                        color = SecondaryText,
                        fontSize = 13.sp
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(recentVideos, key = { it.uri.toString() }) { video ->
                            Row(
                                modifier = Modifier.fillMaxWidth()
                                    .background(Panel, RoundedCornerShape(10.dp))
                                    .padding(horizontal = 12.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.Movie, contentDescription = null, tint = VLCOrange)
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    video.name,
                                    modifier = Modifier.weight(1f),
                                    color = MainText,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 14.sp
                                )
                                Button(
                                    onClick = {
                                        selectedUri = video.uri
                                        selectedName = video.name
                                        playbackError = null
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = VLCOrange,
                                        contentColor = Color.Black
                                    )
                                ) {
                                    Text("Play")
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

private fun queryDisplayName(context: android.content.Context, uri: Uri): String {
    return try {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) cursor.getString(index) else null
                } else null
            } ?: (uri.lastPathSegment ?: "Selected video")
    } catch (_: Exception) {
        uri.lastPathSegment ?: "Selected video"
    }
}
