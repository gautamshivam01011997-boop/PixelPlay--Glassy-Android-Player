# PixelPlay — Premium Android Video Player Starter

A Google Pixel / Material You-inspired Android video player starter built with Kotlin, Jetpack Compose, Material 3 and AndroidX Media3 ExoPlayer.

## Implemented in this revision
- Material You dynamic dark color scheme on Android 12+; curated dark fallback on older Android versions
- Local video picker using Android's document picker (no broad storage permission)
- Video playback, seek bar, play/pause, +/- 10-second seek and playback speed from 0.5x to 2x
- Fullscreen playback with immersive system bars
- Load an external SRT or WebVTT subtitle file
- Subtitle track enable/disable toggle
- Remembers the last selected video URI/name when Android's persisted document permission remains available
- Playback error message for unsupported/unavailable media

## Not implemented yet
- Full library scan, thumbnails, folders, search, playlists and watch history
- Swipe gestures for brightness/volume/seek
- Background playback/media notification service
- Picture-in-Picture
- Dedicated audio-track selector and subtitle timing adjustment
- Network stream browser and broad codec compatibility testing
- Production icon, automated tests, signed release APK

## Build APK
This environment did not have Gradle or an Android SDK installed, so no APK could be compiled or device-tested here.

1. Install Android Studio (JDK 17 recommended).
2. Open this folder in Android Studio and let Gradle sync.
3. Install the Android SDK platform/build tools requested by the IDE.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated debug APK on a test device and validate playback with several local video formats.

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35 and Media3 1.5.1. It is a starter implementation and should be built/tested before distribution.


## VLC-style redesign

The main screen has been simplified to a dark VLC-inspired layout with an orange accent, a standard Media3 PlayerView controller, an Open video button, recent selections, and a visible playback error message. Select a local video using Android's document picker. This is a source-code update; build and test the APK with the included GitHub Actions workflow before distributing it.
