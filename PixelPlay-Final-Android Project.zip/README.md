# PixelPlay — Android Video & Audio Player

PixelPlay is a Kotlin + Jetpack Compose + AndroidX Media3 ExoPlayer starter app with a premium, iPhone-inspired glass UI.

## Features in this project
- PixelPlay custom vector logo in the app header and app icon
- Dark glass-style translucent panels, subtle borders, rounded corners, and accent gradients
- Seven selectable themes: Pixel Purple, AMOLED Black, Ocean Blue, Forest Green, Sunset Orange, Rose Pink, and Light
- Android document picker for local video files (`video/*`)
- Android document picker for local audio files (`audio/*`)
- Media3 playback view and playback controls
- 10-second seek backward/forward and a seek slider
- Playback speed presets (0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x)
- External subtitle picker for common SRT/VTT formats
- GitHub Actions workflow to build a debug APK and upload it as an artifact

## Build locally
1. Open this folder in a recent stable Android Studio.
2. Use JDK 17.
3. Wait for Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Build with GitHub Actions
1. Upload the *contents* of this extracted project into the root of a GitHub repository.
2. Open **Actions**.
3. Run **Build PixelPlay APK** with **Run workflow**.
4. Download the `PixelPlay-debug-APK` artifact after a successful build.

## Important codec note
Media3 uses Android's available decoders. Common MP4/H.264/AAC and many MKV files may work, but no ordinary Android player can promise every codec/container on every device without extra decoders or transcoding. Some AC3, DTS, TrueHD, WMV, unusual HEVC profiles, or damaged files may not play on a given phone. This starter does not bundle FFmpeg or proprietary codecs.

## Current limitations
This is a functional starter project, not a feature-for-feature VLC clone. It does not yet include automatic full-device media indexing, network streaming, casting, Picture-in-Picture, gesture-based brightness/volume, a dedicated audio-track chooser, persistent theme saving, or true real-time frosted-background blur. The current glass style is translucent panels with subtle borders/gradients. Build and test the APK before distributing it.
